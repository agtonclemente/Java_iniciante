
package metodos;

/**
 *
 * @author Celina
 */
public class TesteCarro {

    
    public static void main(String[] args) {
     
        Carro c = new Carro();
       
       
		// atribui o valor Fiat ao atributo marca
		c.setMarca("Fiat");
		
                
                //mostra o valor que foi passado  
		System.out.println(c.getMarca());
    }
    
}
