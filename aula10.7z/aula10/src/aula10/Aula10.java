
package aula10;

/**
 *
 * @author Celina
 */
public class Aula10 {

    
    public static void main(String[] args) {
        
        	Carro carro = new Carro();
                
		carro.marca = "Fiat";
		carro.modelo = "127";
		//carro.numPassageiros = 10;
		carro.capCombustivel = 100;
		carro.consumoCombustivel = 0.2;

		System.out.println(carro.numPassageiros);
		
		Carro c = new Carro("Fiat", "127", 10, 100, 0.2);
		
		System.out.println(c.marca);
		System.out.println(c.modelo);
		System.out.println(c.numPassageiros);
		System.out.println(c.capCombustivel);
		System.out.println(c.consumoCombustivel);
		
		//Carro2 carro2 = new Carro2();
    }
    
}
