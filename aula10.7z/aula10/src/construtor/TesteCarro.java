
package construtor;

/**
 *
 * @author Celina
 */
public class TesteCarro {

    public static void main(String[] args) {
        	
		Carro c = new Carro("Fiat", "127");

		System.out.println(c.numPassageiros);
    }
    
}
